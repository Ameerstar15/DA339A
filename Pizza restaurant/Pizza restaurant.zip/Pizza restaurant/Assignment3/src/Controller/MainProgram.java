/*

Alameer Albadrani
Am2541
180122
 */

package Controller;

public class MainProgram {
    public static void main(String[] args) {

        Controller controller = new Controller();
    }
}
