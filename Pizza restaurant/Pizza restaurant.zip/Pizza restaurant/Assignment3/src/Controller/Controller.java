/*

Alameer Albadrani
Am2541
180122
 */



package Controller;

import Model.*;
import View.MainFrame;

import javax.swing.*;
import java.util.ArrayList;

public class Controller {
    private Margareta margareta;
    private Kebab kebab;
    private Peperoni peperoni;
    private Chicken chicken;
    private Salami salami;

    private int amount;
    private int orderNumber;
    private double price;
    private int antal;

    private MainFrame view;


    public Controller() {
        view = new MainFrame(800, 600, this);
        margareta = new Margareta(100, "Margareta Pizza");
        kebab = new Kebab(120, "Kebab Pizza");
        peperoni = new Peperoni(130, "Peperoni Pizza");
        chicken = new Chicken(150, "Chicken Pizza");
        salami = new Salami(140, "Salami Pizza");

        orderNumber = 1;

    }


    ArrayList<String> pizza = new ArrayList<>();
    ArrayList<String> order = new ArrayList<>();
    ArrayList<String> stats = new ArrayList<>();

    public void addItemToOrder(int index) {

        JTextField amountCount = new JTextField(5);
        JPanel panel = new JPanel();
        panel.add(new JLabel("How many pizza you want to order"));
        panel.add(amountCount);
        int temp = JOptionPane.showConfirmDialog(null, panel,
                "Select quantity of pizza items", JOptionPane.OK_CANCEL_OPTION);
        if (temp == JOptionPane.OK_OPTION && !(amountCount.getText().isEmpty())) {
            try {
                amount = Integer.parseInt(amountCount.getText());
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Please insert a number");
            }

            if (amount != 0) {
                if (orderNumber == 1 && price == 0) {
                    order.add("-------------------/ Order  /-------------------");
                    order.add("--------------------------------------");


                    stats.add("--------------------------------------");

                    view.updateOrderList(order.toArray(new String[0]));
                }
                if (index == 0) {
                    margareta.setAmount(amount);
                    order.add(margareta.getPizzaWithAmount());
                    stats.add(margareta.getPizzaWithAmount());
                    price += margareta.getPriceWithAmount();
                    antal += amount;
                }
                if (index == 1) {
                    kebab.setAmount(amount);
                    order.add(kebab.getPizzaWithAmount());
                    stats.add(kebab.getPizzaWithAmount());

                    price += kebab.getPriceWithAmount();
                    antal += amount;
                }
                if (index == 2) {
                    peperoni.setAmount(amount);
                    order.add(peperoni.getPizzaWithAmount());
                    stats.add(peperoni.getPizzaWithAmount());

                    price += peperoni.getPriceWithAmount();
                    antal += amount;
                }
                if (index == 3) {
                    chicken.setAmount(amount);
                    order.add(chicken.getPizzaWithAmount());
                    stats.add(chicken.getPizzaWithAmount());


                    price += chicken.getPriceWithAmount();
                    antal += amount;
                }
                if (index == 4) {
                    salami.setAmount(amount);
                    order.add(salami.getPizzaWithAmount());
                    stats.add(salami.getPizzaWithAmount());

                    price += salami.getPriceWithAmount();
                    antal += amount;
                }
                view.emptyPrice1();
                String value = Double.toString(price);
                view.setPrice(value);
                String numOrder = Integer.toString(orderNumber);
                view.emptyOrder();
                view.setOrderNumber(numOrder);
            } else {
                JOptionPane.showMessageDialog(null, "No Order confirmed");
            }

        } else {
            JOptionPane.showMessageDialog(null, "No Order confirmed");
        }
        view.updateOrderList(order.toArray(new String[0]));
        view.updateOrderList(stats.toArray(new String[0]));

    }


    public void setToFoodMenu() {
        pizza.clear();
        pizza.add(0, margareta.getPizzaName());
        pizza.add(1, kebab.getPizzaName());
        pizza.add(2, peperoni.getPizzaName());
        pizza.add(3, chicken.getPizzaName());
        pizza.add(4, salami.getPizzaName());
        view.updateList(pizza.toArray(new String[0]));

    }

    public void placeOrder() {
        if (price > 0) {
            String value = Double.toString(price);
            String numOrder = Integer.toString(orderNumber);
            view.emptyOrder();
            view.setOrderNumber(numOrder);
            order.add("");
            order.add("--------------------------------------");
            order.add("The sum of Order " + numOrder + " is:");
            order.add( "Quantity:  " + antal);
            order.add("Total price: " + value + " Kr");
            orderNumber = orderNumber + 1;
            order.add("--------------------------------------");
            order.add("**************************************");
            view.updateOrderList(order.toArray(new String[0]));

            stats.add("Order Numer"+numOrder);
            stats.add("Order :"+ numOrder + " "+  "Quantatiy :"+antal + " "+" Value :" +value);
            stats.add("");
            stats.add("--------------------------------------");
            view.updateOrderList(stats.toArray(new String[0]));

        } else {
            JOptionPane.showMessageDialog(null, "No order yet!! ");
        }

            antal = 0;
        price = 0;
    }

    public void showOrder()
    {

       view.updateList(stats.toArray(new String[0]));
    }

        public void exit () {
            int option = JOptionPane.showConfirmDialog(null, "Exit, Are you sure");
            if (option == 0) {
                System.exit(0);
            }
        }



}