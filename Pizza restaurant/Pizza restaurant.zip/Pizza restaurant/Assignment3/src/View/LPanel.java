/*

Alameer Albadrani
Am2541
180122
 */

package View;

import Controller.Controller;

import javax.swing.*;

public class LPanel extends JPanel {
    private JList<String > menu;
    private JButton showDrinks;
    private JButton showFood;
    private JButton addToOrder;
    private JLabel title;

    private int width;
    private int height;

    private Controller controller;

    public LPanel(int width, int height, Controller controller) {
        this.controller = controller;
        this.setLayout(null);
        this.width = width;
        this.height = height;
        this.setSize(width, height);
        setLocation(0, 0);
        setUp();
    }

    public void setUp() {
        title = new JLabel("MAU'S Pizzeria");
        title.setLocation((width / 2) - 45, 0);
        title.setSize(90, 20);
        this.add(title);

        menu = new JList<>();
        menu.setLocation(0, 23);
        menu.setSize(width, height - 100);
        this.add(menu);


        showFood = new JButton("Menu");
        showFood.setEnabled(true);
        showFood.setSize(width / 3, 30);
        showFood.setLocation(0, height - 75);
        showFood.addActionListener(l -> controller.setToFoodMenu());
        this.add(showFood);

        addToOrder = new JButton("Lägg till");
        addToOrder.setEnabled(true);
        addToOrder.setSize(width / 3, 30);
        addToOrder.addActionListener(l -> controller.addItemToOrder(getListIndex()));
        addToOrder.setLocation(width - (width / 3), height - 75);
        this.add(addToOrder);
    }

    public int getListIndex(){
        return menu.getSelectedIndex();
    }
    public JList<String > getMenu() {
        return menu;
    }

    public void setMenu(JList<String> menu) {
        this.menu = menu;
    }

    public JButton getShowDrinks() {
        return showDrinks;
    }

    public void setShowDrinks(JButton showDrinks) {
        this.showDrinks = showDrinks;
    }

    public JButton getShowFood() {
        return showFood;
    }

    public void setShowFood(JButton showFood) {
        this.showFood = showFood;
    }

    public JButton getAddToOrder() {
        return addToOrder;
    }

    public void setAddToOrder(JButton addToOrder) {
        this.addToOrder = addToOrder;
    }

    public JLabel getTitle() {
        return title;
    }

    public void setTitle(JLabel title) {
        this.title = title;
    }

    @Override
    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    @Override
    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public void updateList(String[] stringList) {
        menu.setListData(stringList);
    }
}
