/*

Alameer Albadrani
Am2541
180122
 */

package View;

import Controller.Controller;

import javax.swing.*;


public class MainFrame extends JFrame {
    private MainPanel mainPanel;
    private Controller controller;

    public MainFrame(int width, int height, Controller controller) {
        super("MAU´s Restaurant");
        this.controller = controller;
        this.setResizable(true);
        this.setSize(width, height);
        this.mainPanel = new MainPanel(width, height, controller);
        this.setContentPane(mainPanel);
        this.setVisible(true);

    }


    public MainPanel getMainPanel() {
        return mainPanel;
    }

    public void setMainPanel(MainPanel mainPanel) {
        this.mainPanel = mainPanel;
    }

    public void updateList(String[] stringList) {
        mainPanel.getlPanel().updateList(stringList);
    }

    public void updateOrderList(String[] stringList) {
        mainPanel.getrPanel().updateList(stringList);
    }


    public void setPrice(String  price) {
        mainPanel.getrPanel().setPrice(price);
    }


    public void emptyPrice1() {
        mainPanel.getrPanel().emptyPrice1();
    }

    public void setOrderNumber(String orderNumber) {
        mainPanel.getrPanel().setTitle(orderNumber);
    }

    public void emptyOrder() {
        mainPanel.getrPanel().emptyOrder();
    }

}
