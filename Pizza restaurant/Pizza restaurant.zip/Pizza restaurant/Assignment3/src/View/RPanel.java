/*

Alameer Albadrani
Am2541
180122
 */

package View;


import Controller.Controller;

import javax.swing.*;

public class RPanel extends JPanel {
    private JList<Object> orderList;
    private JButton exit;
    private JButton createOrder;
    private JButton showOrder;
    private JLabel title;
    private JLabel price;

    private int width;
    private int height;

    private Controller controller;

    public RPanel(int width, int height, Controller controller) {
        this.controller = controller;
        this.setLayout(null);
        this.width = width;
        this.height = height;
        this.setSize(width, height);
        setLocation(width, 0);
        setUp();

    }

    public void setUp() {
        title = new JLabel("ORDER");
        title.setLocation(0, 0);
        title.setSize(width / 2, 20);
        this.add(title);

        price = new JLabel("PRICE: ");
        price.setLocation(width / 2 + 10, 0);
        price.setSize(130, 20);
        this.add(price);

        orderList = new JList<>();
        orderList.setLocation(0, 23);
        orderList.setSize(width, height - 100);
        this.add(orderList);


        exit = new JButton("Exit");
        exit.setEnabled(true);
        exit.setSize(width / 3, 30);
        exit.setLocation(width / 3, height - 75);
        exit.addActionListener(l -> controller.exit());
        this.add(exit);

        createOrder = new JButton("Beställ");
        createOrder.setEnabled(true);
        createOrder.setSize(width / 3, 30);
        createOrder.setLocation(0, height - 75);
        createOrder.addActionListener(l -> controller.placeOrder());
        this.add(createOrder);


        showOrder = new JButton("Orderlista");
        showOrder.setEnabled(true);
        showOrder.setVisible(true);
        showOrder.setSize(width / 3, 30);
        showOrder.setLocation(width - (width / 3), height - 75);
        showOrder.addActionListener(l -> controller.showOrder());
        this.add(showOrder);

    }


    public JList<Object> getOrderList() {
        return orderList;
    }

    public void setOrderList(JList<Object> orderList) {
        this.orderList = orderList;
    }

    public JButton getCreateOrder() {
        return createOrder;
    }

    public void setCreateOrder(JButton createOrder) {
        this.createOrder = createOrder;
    }

    public JLabel getTitle() {
        return title;
    }

    public void setTitle(String numberOrder) {
        title.setText(title.getText() + "ORDER: " + numberOrder);
    }

    public JButton getShowOrder() {
        return showOrder;
    }

    public void setshowOrder(JButton showOrder) {
        this.showOrder = showOrder;
    }

    @Override
    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    @Override
    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public JButton getExit() {
        return exit;
    }


    public void setExit(JButton exit) {
        this.exit = exit;
    }

    public JLabel getPrice() {
        return price;
    }

    public void setPrice(String price1) {
        price.setText(price.getText() + "PRICE: " + price1 + " :-");
    }

    public void updateList(String[] stringList) {
        orderList.setListData(stringList);
    }

    public void updateStats(String[] stringList) {
        orderList.setListData(stringList);
    }
    public void emptyPrice() {
        price.setText("PRICE: 0.0 :-");
    }

    public void emptyPrice1() {
        price.setText("");
    }


    public void emptyOrder() {
        title.setText("");
    }
}
