/*

Alameer Albadrani
Am2541
180122
 */
package Model;

public class Chicken extends Margareta {
    public Chicken(double price, String name) {
        super(price, name);
    }
    @Override
    public String getPizzaName() {
        String out = "";
        out += getName()+": Chicken, Tomato sauce , Mozzarella  ";
        out += getPrice()+" Kr.";
        return out;
    }

    @Override
    public String getPizzaWithAmount() {
        String out = "";
        out += getName()+":   ";
        out += getPriceWithAmount()+" Kr  Amount: ";
        out += getAmount()+" pcs";
        return out;
    }

    public double getPriceWithAmount() {
        double out = getPrice();
        if (super.getAmount()>0){
            out*= super.getAmount();
        }
        return out;
    }
}
