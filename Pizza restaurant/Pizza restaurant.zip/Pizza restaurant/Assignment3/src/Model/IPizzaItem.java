/*

Alameer Albadrani
Am2541
180122
 */
package Model;

public interface IPizzaItem {
    String getPizzaName();
    String getPizzaWithAmount();
    int getAmount();
    void setAmount(int amount);
}
