/*

Alameer Albadrani
Am2541
180122
 */

package Model;

public abstract class PizzaItem implements IPizzaItem {

    private double price;
    private String name;
    private int amount;


    public PizzaItem(double price, String name) {
        this.price = price;
        this.name = name;
    }


    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
    public abstract String getPizzaName();
    public abstract String getPizzaWithAmount();
    public abstract double getPriceWithAmount();
}
