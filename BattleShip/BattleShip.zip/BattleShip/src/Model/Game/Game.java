/*

Sinan Sabree  al6898
Alameer Albadrani  am2541


 */
package Model.Game;

import java.util.Arrays;
import Controller.GameController;
import Model.Ships.Battleship;
import Model.Ships.Cruiser;
import Model.Ships.Destroyer;
import Model.Ships.Ship;
import Model.Ships.ShipType;
import Model.Ships.Submarine;
import Model.Ships.Torpedo;

    public class Game implements Comparable {

        private int score;
        private int rows;
        private int columns;
        private Ship[] ships;
        private int shipsCount;
        private String userName;
        private Ship lastHit;
        private GameController controller;



        public Game(int rows, int columns, GameController controller) {

            setController(controller);

            setRows(rows);
            setColumns(columns);
            setScore(getRows() * getColumns());

            setShips(new Ship[5]);

            spawnShips();

            System.out.println("Started new game.");

        }

        private void spawnShips() {

            // Spawns default ships to map.

            addShip(ShipType.Submarine, 0, 1, 0);
            addShip(ShipType.Torpedo, 2, 2, 1);
            addShip(ShipType.Cruiser, 0, 7, 1);
            addShip(ShipType.Battleship, 0, 0, 0);
            addShip(ShipType.Destroyer, 6, 5, 1);

        }

        public Ship addShip(ShipType type, int x, int y, int angle) {

            // Adds ship to array and returns created ship.
            // Angle:
            // 0: Horizontal
            // 1: Vertical

            Ship ship = null;

            if (x < 0 || x > getColumns() || y < 0 || y > getRows()) {
                getController().getView().displayMesage("Tried setting ship out of bounds.");
                return null;
            }

            switch (type) {

                case Torpedo:
                    ship = new Torpedo();
                    break;
                case Submarine:
                    ship = new Submarine();
                    break;
                case Destroyer:
                    ship = new Destroyer();
                    break;
                case Cruiser:
                    ship = new Cruiser();
                    break;
                case Battleship:
                    ship = new Battleship();
                    break;

                default:
                    break;
            }

            ship.setLocation(new int[ship.getLength()][]); // Sets start point of ship.

            for (int i = 0; i < ship.getLength(); i++) {

                if (angle == 0) { // Horizontal

                    ship.getLocation()[i] = new int[] {
                            x + i, y
                    };

                } else {

                    ship.getLocation()[i] = new int[] {
                            x, y + i
                    };

                }

            }

            for (Ship otherShip : getShips()) {

                if (ship == otherShip || otherShip == null) {
                    continue;
                }
            }

            ships[shipsCount] = ship;
            shipsCount++;

            return ship;

        }

        public GameController getController() {
            return this.controller;
        }

        public void setController(GameController controller) {
            this.controller = controller;
        }

        public Ship getLastHit() {
            return this.lastHit;
        }

        public void setLastHit(Ship lastHit) {
            this.lastHit = lastHit;
        }

        public String getUserName() {
            return this.userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public int getShipsCount() {
            return this.shipsCount;
        }

        public void setShipsCount(int shipsCount) {
            this.shipsCount = shipsCount;
        }

        public Ship[] getShips() {
            return this.ships;
        }

        public void setShips(Ship[] ships) {
            this.ships = ships;
        }

        public int getScore() {
            return this.score;
        }

        public void setScore(int score) {
            this.score = score;
        }

        public int getRows() {
            return this.rows;
        }

        public void setRows(int rows) {
            this.rows = rows;
        }

        public int getColumns() {
            return this.columns;
        }

        public void setColumns(int columns) {
            this.columns = columns;
        }

        public boolean hit(int x, int y) {

            // Change to function that can detect if ship is there. Damage another
            // functions.

            int[] hit = { x, y };

            for (Ship ship : ships) {

                if (ship == null) {
                    continue;
                }

                for (int[] location : ship.getLocation()) {

                    if (Arrays.equals(hit, location)) {

                        // We have a hit!

                        setLastHit(ship);

                        ship.damage();

                        if (ship.getHealth() == 0) {
                            shipsCount--;
                        }

                        return true;
                    }

                }
            }

            // If not a hit...

            setScore(score - 1);

            return false;

        }

        @Override
        public int compareTo(Object o) {

            int comparage = ((Game) o).getScore();
            return comparage - this.getScore();

        }

        @Override
        public String toString() {
            return String.format("Name: %s Score: %s", getUserName(), getScore());
        }

    }


