/*

Sinan Sabree  al6898
Alameer Albadrani  am2541


 */

package Model.Ships;

public class Destroyer extends Ship {

    public Destroyer() {
        setLength(4);
        setHealth(getLength());
        setType(ShipType.Destroyer);
    }

}
