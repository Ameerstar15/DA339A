/*

Sinan Sabree  al6898
Alameer Albadrani  am2541


 */

package Model.Ships;

public class Torpedo extends Ship {

    public Torpedo() {

        setLength(2);
        setHealth(getLength());
        setType(ShipType.Torpedo);

    }

}
