/*

Sinan Sabree  al6898
Alameer Albadrani  am2541


 */
package Model.Ships;

public class Cruiser extends Ship{

    public Cruiser() {
        setLength(3);
        setHealth(getLength());
        setType(ShipType.Cruiser);
    }

}