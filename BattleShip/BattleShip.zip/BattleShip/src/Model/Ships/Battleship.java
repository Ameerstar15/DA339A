/*

Sinan Sabree  al6898
Alameer Albadrani  am2541


 */
package Model.Ships;

public class Battleship extends Ship
{
    public Battleship() {
        setLength(5);
        setHealth(getLength());
        setType(ShipType.Battleship);
    }

}
