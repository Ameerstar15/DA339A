/*

Sinan Sabree  al6898
Alameer Albadrani  am2541


 */

package Model.Ships;

public class Submarine extends Ship {

    public Submarine() {

        setLength(1);
        setHealth(getLength());
        setType(ShipType.Submarine);

    }

}
