/*

Sinan Sabree  al6898
Alameer Albadrani  am2541


 */

package Model.Ships;

public enum ShipType
{
    Submarine,
    Torpedo,
    Destroyer,
    Cruiser,
    Battleship

}
