/*

Sinan Sabree  al6898
Alameer Albadrani  am2541


 */

import Controller.GameController;


public class Run
{
    public static void main(String[] args) {
        new GameController();
    }
}
