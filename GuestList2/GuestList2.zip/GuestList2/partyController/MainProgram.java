package partyController;

public class MainProgram
{
    public static void main(String[] args)
    {
        int maxNbrOfGuests = 10; // Change thi line later. Only using 10 as a default value to make compilations possible.
        /* Write code to read max number of guests from the user by using one of
         - JOptionPane
         - Scanner and prompt
        */

        Controller controller = new Controller(maxNbrOfGuests);
    }
}
